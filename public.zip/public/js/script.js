console.log("Testing Responsive Navigation");

// Variable Declarations
const menu_icon = document.querySelector('#menu_icon');
const mob_nav = document.querySelector('#mob_nav');
const modal = document.querySelector('.modal');
const modal2 = document.querySelector('.modal2');
const modal3 = document.querySelector('.modal3');

//Nitin Wadhwani
const nitin_btn = document.querySelector('.card-nitin');
const card_display_nitin = document.querySelector('.card-display-nitin');
const close_btn_nitin = document.querySelector('.close_btn_nitin');


//Indira Malkani
const indira_btn = document.querySelector('.card-indira');
const card_display_indira = document.querySelector('.card-display-indira');
const close_btn_indira = document.querySelector('.close_btn_indira');


//MP Singh
const mpsingh_btn = document.querySelector('.card-mpsingh');
const card_display_mpsingh = document.querySelector('.card-display-mpsingh');
const close_btn_mpsingh = document.querySelector('.close_btn_mpsingh');


//Card Display Nitin Wadhwani
nitin_btn.addEventListener('click', () => {
    if(card_display_nitin.classList.contains('hidden')) {
        card_display_nitin.classList.remove('hidden');
    }
    else {
        card_display_nitin.classList.add('hidden');
    }
});

// Card Display Indira
indira_btn.addEventListener('click', () => {
    if(card_display_indira.classList.contains('hidden')) {
        card_display_indira.classList.remove('hidden');
    }
    else {
        card_display_indira.classList.add('hidden');
    }
});

// Card Display MP Singh
mpsingh_btn.addEventListener('click', () => {
    if(card_display_mpsingh.classList.contains('hidden')) {
        card_display_mpsingh.classList.remove('hidden');
    }
    else {
        card_display_mpsingh.classList.add('hidden');
    }
});



//When the user clicks anywhere outside of the modal, close it
window.onclick = (event) => {
    if(event.target === modal2 || event.target === modal || event.target === modal3){
        modal.classList.add('hidden');
        modal2.classList.add('hidden');
        modal3.classList.add('hidden');
    }
}

//Close Buttons
close_btn_nitin.addEventListener('click', () => {
    card_display_nitin.classList.add('hidden');
});

close_btn_indira.addEventListener('click', () => {
    card_display_indira.classList.add('hidden');
});

close_btn_mpsingh.addEventListener('click', () => {
    card_display_mpsingh.classList.add('hidden');
});

//Event Listeners
menu_icon.addEventListener('click', () => {
    // console.log("Menu Icon");
    if(mob_nav.classList.contains('hidden')){
        mob_nav.classList.remove('hidden');
    }
    else {
        mob_nav.classList.add('hidden');
    }
})
// console.log(menu_icon,mob_nav);

//Inside mob navigation

//Variable Declarations

//Programs
const mob_menu_icon = document.querySelector('#mob_programs_btn');
const mob_programs_menu = document.querySelector('#mob_programs_menu');
const mob_prog = document.querySelector('#mob_prog');
// console.log(mob_programs_menu);

//Resouces
const mob_resources_btn = document.querySelector('#mob_resources_btn');
const mob_resources_menu = document.querySelector('#mob_resources_menu');
const mob_resource = document.querySelector('#mob_resource');


//Event Listeners

//1. Programs
mob_menu_icon.addEventListener('click', () => {
    // console.log("Mob Menu");
    if(mob_programs_menu.classList.contains('hidden')){
        mob_programs_menu.classList.remove('hidden');
    }
    else {
        mob_programs_menu.classList.add('hidden');
    }
})

mob_prog.addEventListener('click', () => {
    if(mob_programs_menu.classList.contains('hidden')){
        mob_programs_menu.classList.remove('hidden');
    }
    else {
        mob_programs_menu.classList.add('hidden');
    }
})

//2. Resources
mob_resources_btn.addEventListener('click', () => {
    if(mob_resources_menu.classList.contains('hidden')){
        mob_resources_menu.classList.remove('hidden');
    }
    else {
        mob_resources_menu.classList.add('hidden');
    }
})

mob_resource.addEventListener('click', () => {
    if(mob_resources_menu.classList.contains('hidden')){
        mob_resources_menu.classList.remove('hidden');
    }
    else {
        mob_resources_menu.classList.add('hidden');
    }
})



//3. Contact 